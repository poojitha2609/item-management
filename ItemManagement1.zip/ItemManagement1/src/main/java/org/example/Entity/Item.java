package org.example.Entity;

import jakarta.persistence.Table;
import lombok.Data;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "item")
@Data
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "itemno")
    private Long itemNo;

    @Column(name = "name")
    @Size(min = 3, max = 50, message = "item name must be between 3 and 50 characters")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "price")

    private float price;

    @Column(name = "stockqty")
    @Min(value = 1 , message = "quantity should be grater than one")
    private int stockQty;

}
